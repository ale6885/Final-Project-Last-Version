For the frameworks assignment I built a web application using Django as a backand framework and database PostgreSQL. 
After setting up tha Django evironemnt and completing all requirements I designed the database scheme.
I built all the core backend functionalities for the blog. 
I defined the fronted part using HTML, Bootstrap, CSS, and integrating JavaScript-driven functionalities.
I tested for functionality, responsiveness and security.
Hosted application on Render https://fivedjango-project.onrender.com
GitHub link https://github.com/ale6885/5.-Django-Project_old
